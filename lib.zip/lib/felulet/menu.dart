import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'profil.dart';

class MenuItemData {
  final IconData icon;
  final String title;
  final VoidCallback? onTap;

  const MenuItemData({required this.icon, required this.title, this.onTap});
}

/// Meniu lateral stânga simplu
class LeftSideMenu extends StatelessWidget {
  final List<MenuItemData> items;
  final int selectedIndex;
  final ValueChanged<int>? onItemSelected;
  final double width;

  const LeftSideMenu({
    Key? key,
    this.items = const [
      MenuItemData(icon: Icons.home_outlined, title: 'Acasa'),
      MenuItemData(icon: Icons.person_outline, title: 'Profil'),
      MenuItemData(icon: Icons.settings_outlined, title: 'Setari'),
      MenuItemData(icon: Icons.help_outline, title: 'Ajutor'),
      MenuItemData(icon: Icons.logout, title: 'Deconectare'),
    ],
    this.selectedIndex = 0,
    this.onItemSelected,
    this.width = 240,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bg = theme.colorScheme.surface;
    final accent = theme.colorScheme.primary;
    final textColor = theme.textTheme.bodyMedium?.color;

    return Container(
      width: width,
      decoration: BoxDecoration(
        color: bg,
        border: Border(
          right: BorderSide(color: theme.dividerColor.withOpacity(0.5)),
        ),
      ),
      child: SafeArea(
        left: true,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Antet / logo
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
              child: Row(
                children: [
                  Container(
                    height: 42,
                    width: 42,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(Icons.flutter_dash, color: accent),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Aplicatie',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: textColor,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            // Elemente meniu
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 6),
                itemBuilder: (context, index) {
                  final item = items[index];
                  final selected = index == selectedIndex;

                  return Material(
                    color: selected ? accent.withOpacity(0.08) : Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        if (item.onTap != null) {
                          item.onTap!();
                        }
                        if (onItemSelected != null) {
                          onItemSelected!(index);
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                        child: Row(
                          children: [
                            // indicator stânga
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 250),
                              width: 4,
                              height: 36,
                              decoration: BoxDecoration(
                                color: selected ? accent : Colors.transparent,
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Icon(item.icon, color: selected ? accent : theme.iconTheme.color),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Text(
                                item.title,
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  color: selected ? accent : textColor,
                                  fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            // Subsol opțional
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'Versiune 1.0.0',
                style: theme.textTheme.bodySmall?.copyWith(color: theme.hintColor),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Pagina container care gazduieste meniul si continutul.
class MenuScreen extends StatefulWidget {
  const MenuScreen({Key? key}) : super(key: key);

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  int _selectedIndex = 0;

  List<MenuItemData> _items(BuildContext context) => [
        MenuItemData(icon: Icons.home_outlined, title: 'Acasa', onTap: () => setState(() => _selectedIndex = 0)),
        MenuItemData(icon: Icons.person_outline, title: 'Profil', onTap: () => setState(() => _selectedIndex = 1)),
        MenuItemData(icon: Icons.settings_outlined, title: 'Setari', onTap: () => setState(() => _selectedIndex = 2)),
        MenuItemData(icon: Icons.help_outline, title: 'Ajutor', onTap: () => setState(() => _selectedIndex = 3)),
        MenuItemData(
          icon: Icons.logout,
          title: 'Deconectare',
          onTap: () => _logout(context),
        ),
      ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final titles = ['Acasa', 'Profil', 'Setari', 'Ajutor'];
    final width = MediaQuery.of(context).size.width;
    final isCompact = width < 700;

    final content = Container(
      color: theme.colorScheme.background.withOpacity(0.02),
      child: IndexedStack(
        index: _selectedIndex,
        children: [
          _homePlaceholder(theme),
          const ProfilePage(),
          _settingsPlaceholder(theme),
          _helpPlaceholder(theme),
        ],
      ),
    );

    if (isCompact) {
      return Scaffold(
        appBar: AppBar(
          title: Text(titles[_selectedIndex]),
        ),
        drawer: Drawer(
          child: SafeArea(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8),
              children: [
                for (var i = 0; i < _items(context).length; i++)
                  ListTile(
                    leading: Icon(_items(context)[i].icon),
                    title: Text(_items(context)[i].title),
                    selected: i == _selectedIndex,
                    onTap: () {
                      final action = _items(context)[i].onTap;
                      Navigator.of(context).pop();
                      if (action != null) action();
                    },
                  ),
              ],
            ),
          ),
        ),
        body: content,
      );
    }

    return Scaffold(
      body: Row(
        children: [
          LeftSideMenu(
            items: _items(context),
            selectedIndex: _selectedIndex,
            onItemSelected: (i) => setState(() => _selectedIndex = i),
          ),
          Expanded(child: content),
        ],
      ),
    );
  }

  Future<void> _logout(BuildContext context) async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove('auth_token');
    if (!mounted) return;
    Navigator.of(context).pushReplacementNamed('/login');
  }

  Widget _homePlaceholder(ThemeData theme) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.dashboard_outlined, size: 56, color: theme.colorScheme.primary.withOpacity(0.7)),
            const SizedBox(height: 12),
            Text('Continut - Acasa', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text('Alege pagina dorita din meniul din stanga.', style: theme.textTheme.bodyMedium),
          ],
        ),
      );

  Widget _settingsPlaceholder(ThemeData theme) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.settings_outlined, size: 56, color: theme.colorScheme.primary.withOpacity(0.7)),
            const SizedBox(height: 12),
            Text('Continut - Setari', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text('Setarile vor fi disponibile aici.', style: theme.textTheme.bodyMedium),
          ],
        ),
      );

  Widget _helpPlaceholder(ThemeData theme) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.help_outline, size: 56, color: theme.colorScheme.primary.withOpacity(0.7)),
            const SizedBox(height: 12),
            Text('Continut - Ajutor', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text('Documentatia si suportul vor fi aici.', style: theme.textTheme.bodyMedium),
          ],
        ),
      );
}
