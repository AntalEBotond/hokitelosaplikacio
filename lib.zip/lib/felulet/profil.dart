import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/api_service.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final ImagePicker _picker = ImagePicker();

  final TextEditingController _nameCtrl = TextEditingController();
  final TextEditingController _descCtrl = TextEditingController();

  String? _avatarPath;
  Uint8List? _avatarBytes; // web avatar bytes
  String? _avatarUrl; // from server if available
  String? _facebook;
  String? _instagram;
  String? _tiktok;
  String? _youtube;

  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
    _nameCtrl.addListener(_saveName);
    _descCtrl.addListener(_saveDescription);
  }

  @override
  void dispose() {
    _nameCtrl.removeListener(_saveName);
    _descCtrl.removeListener(_saveDescription);
    _nameCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfile() async {
    final p = await SharedPreferences.getInstance();
    final token = p.getString('auth_token');

    if (token == null) {
      // Fallback: load local-only data if user not authenticated
      setState(() {
        if (kIsWeb) {
          final b64 = p.getString('profile_avatar_b64');
          _avatarBytes = (b64 != null && b64.isNotEmpty) ? base64Decode(b64) : null;
          _avatarPath = null;
        } else {
          _avatarPath = p.getString('profile_avatar');
        }
        _nameCtrl.text = p.getString('profile_name') ?? '';
        _descCtrl.text = p.getString('profile_description') ?? '';
        _facebook = p.getString('profile_facebook');
        _instagram = p.getString('profile_instagram');
        _tiktok = p.getString('profile_tiktok');
        _youtube = p.getString('profile_youtube');
        _avatarUrl = p.getString('profile_avatar_url');
        _loading = false;
      });
      return;
    }

    try {
      final api = ApiService();
      final data = await api.getProfile(token);
      setState(() {
        _nameCtrl.text = (data['full_name'] ?? '') as String;
        _descCtrl.text = (data['description'] ?? '') as String;
        _facebook = data['social_facebook'] as String?;
        _instagram = data['social_instagram'] as String?;
        _tiktok = data['social_tiktok'] as String?;
        _youtube = data['social_youtube'] as String?;
        _avatarUrl = data['avatar_url'] as String?;
        // Keep local avatar if user set it previously (local-first rendering)
        if (kIsWeb) {
          final b64 = p.getString('profile_avatar_b64');
          _avatarBytes = (b64 != null && b64.isNotEmpty) ? base64Decode(b64) : null;
          _avatarPath = null;
        } else {
          _avatarPath = p.getString('profile_avatar');
        }
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Nu s-a putut incarca profilul: $e')),
      );
    }
  }

  Future<void> _saveProfileToServer() async {
    final p = await SharedPreferences.getInstance();
    final token = p.getString('auth_token');
    if (token == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nu esti autentificat.')),
      );
      return;
    }
    try {
      final api = ApiService();
      final payload = <String, dynamic>{
        'full_name': _nameCtrl.text,
        'description': _descCtrl.text,
        'social_facebook': _facebook,
        'social_instagram': _instagram,
        'social_tiktok': _tiktok,
        'social_youtube': _youtube,
        'avatar_url': _avatarUrl,
      };
      final updated = await api.updateProfile(token, payload);
      // Persist a copy locally for offline reads
      p.setString('profile_name', updated['full_name']?.toString() ?? '');
      p.setString('profile_description', updated['description']?.toString() ?? '');
      if (updated['social_facebook'] != null) p.setString('profile_facebook', updated['social_facebook']); else p.remove('profile_facebook');
      if (updated['social_instagram'] != null) p.setString('profile_instagram', updated['social_instagram']); else p.remove('profile_instagram');
      if (updated['social_tiktok'] != null) p.setString('profile_tiktok', updated['social_tiktok']); else p.remove('profile_tiktok');
      if (updated['social_youtube'] != null) p.setString('profile_youtube', updated['social_youtube']); else p.remove('profile_youtube');
      if (updated['avatar_url'] != null) p.setString('profile_avatar_url', updated['avatar_url']); else p.remove('profile_avatar_url');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profil salvat.')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Salvare esuata: $e')),
      );
    }
  }

  void _saveName() async {
    final p = await SharedPreferences.getInstance();
    p.setString('profile_name', _nameCtrl.text);
  }

  void _saveDescription() async {
    final p = await SharedPreferences.getInstance();
    p.setString('profile_description', _descCtrl.text);
  }

  Future<void> _saveAvatarFromXFile(XFile file) async {
    final p = await SharedPreferences.getInstance();
    final token = p.getString('auth_token');
    if (token == null) {
      // Fallback local save when not authenticated
      if (kIsWeb) {
        final bytes = await file.readAsBytes();
        final b64 = base64Encode(bytes);
        await p.setString('profile_avatar_b64', b64);
        setState(() {
          _avatarBytes = bytes;
          _avatarPath = null;
        });
      } else {
        await p.setString('profile_avatar', file.path);
        setState(() {
          _avatarPath = file.path;
          _avatarBytes = null;
        });
      }
      return;
    }

    try {
      final api = ApiService();
      String url;
      if (kIsWeb) {
        final bytes = await file.readAsBytes();
        final name = file.name.isNotEmpty ? file.name : 'avatar.jpg';
        url = await api.uploadAvatarBytes(token, bytes, filename: name);
      } else {
        url = await api.uploadAvatarPath(token, file.path, filename: file.name);
      }
      await p.setString('profile_avatar_url', url);
      setState(() {
        _avatarUrl = url;
        _avatarPath = null;
        _avatarBytes = null;
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Avatar actualizat.')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Eroare upload: $e')));
    }
  }

  Future<void> _clearAvatar() async {
    final p = await SharedPreferences.getInstance();
    final token = p.getString('auth_token');
    if (token != null) {
      try {
        await ApiService().deleteAvatar(token);
        await p.remove('profile_avatar_url');
        setState(() => _avatarUrl = null);
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Stergere avatar esuata: $e')));
        }
      }
    }
    if (kIsWeb) {
      await p.remove('profile_avatar_b64');
      setState(() => _avatarBytes = null);
    } else {
      await p.remove('profile_avatar');
      setState(() => _avatarPath = null);
    }
  }

  Future<void> _saveLink(String key, String? value) async {
    final p = await SharedPreferences.getInstance();
    if (value == null || value.isEmpty) {
      p.remove(key);
    } else {
      p.setString(key, value);
    }
    setState(() {
      if (key == 'profile_facebook') _facebook = value;
      if (key == 'profile_instagram') _instagram = value;
      if (key == 'profile_tiktok') _tiktok = value;
      if (key == 'profile_youtube') _youtube = value;
    });
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? file = await _picker.pickImage(
        source: source,
        maxWidth: 1200,
        maxHeight: 1200,
        imageQuality: 85,
      );
      if (file != null) {
        await _saveAvatarFromXFile(file);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Eroare la incarcare imagine: $e')),
      );
    }
  }

  void _showImageOptions() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Alege din galerie'),
              onTap: () {
                Navigator.of(context).pop();
                _pickImage(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Fa o poza'),
              onTap: () {
                Navigator.of(context).pop();
                _pickImage(ImageSource.camera);
              },
            ),
            if ((_avatarUrl != null && _avatarUrl!.isNotEmpty) ||
                (!kIsWeb && _avatarPath != null && _avatarPath!.isNotEmpty) ||
                (kIsWeb && _avatarBytes != null && _avatarBytes!.isNotEmpty))
              ListTile(
                leading: const Icon(Icons.delete),
                title: const Text('Sterge avatarul'),
                onTap: () {
                  Navigator.of(context).pop();
                  _clearAvatar();
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _editLinkDialog(String title, String prefKey, String? current) async {
    final TextEditingController c = TextEditingController(text: current ?? '');
    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Editeaza: ' + title),
          content: TextField(
            controller: c,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(
              hintText: 'Introdu linkul complet (ex. https://...)',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Anuleaza'),
            ),
            ElevatedButton(
              onPressed: () {
                final val = c.text.trim();
                _saveLink(prefKey, val.isEmpty ? null : val);
                Navigator.of(context).pop();
              },
              child: const Text('Salveaza'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _openLink(String? url) async {
    if (url == null || url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nu exista link setat pentru acest serviciu.')),
      );
      return;
    }
    final uri = Uri.tryParse(url);
    if (uri == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('URL invalid.')),
      );
      return;
    }
    if (!await canLaunchUrl(uri)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nu s-a putut deschide linkul.')),
      );
      return;
    }
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Widget _socialButton(String brand, IconData icon, String? link, String title, String prefKey) {
    final enabled = link != null && link.isNotEmpty;
    BoxDecoration decoFor(String b) {
      switch (b) {
        case 'facebook':
          final base = const Color(0xFF1877F2);
          return BoxDecoration(
            color: enabled ? base : Colors.grey.shade700,
            shape: BoxShape.circle,
            boxShadow: enabled
                ? [BoxShadow(color: base.withOpacity(0.35), blurRadius: 12, offset: const Offset(0, 4))]
                : [],
          );
        case 'instagram':
          return BoxDecoration(
            shape: BoxShape.circle,
            gradient: enabled
                ? const LinearGradient(
                    colors: [
                      Color(0xFFF58529),
                      Color(0xFFDD2A7B),
                      Color(0xFF8134AF),
                      Color(0xFF515BD4),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : LinearGradient(colors: [Colors.grey.shade700, Colors.grey.shade600]),
            boxShadow: enabled
                ? [const BoxShadow(color: Color(0x55212121), blurRadius: 10, offset: Offset(0, 4))]
                : [],
          );
        case 'tiktok':
          return BoxDecoration(
            color: enabled ? Colors.black : Colors.grey.shade700,
            shape: BoxShape.circle,
            boxShadow: enabled
                ? [
                    BoxShadow(color: const Color(0xFF69C9D0).withOpacity(0.4), blurRadius: 10, offset: const Offset(-2, 2)),
                    BoxShadow(color: const Color(0xFFEE1D52).withOpacity(0.4), blurRadius: 10, offset: const Offset(2, 2)),
                  ]
                : [],
          );
        case 'youtube':
          final base = const Color(0xFFFF0000);
          return BoxDecoration(
            color: enabled ? base : Colors.grey.shade700,
            shape: BoxShape.circle,
            boxShadow: enabled
                ? [BoxShadow(color: base.withOpacity(0.35), blurRadius: 12, offset: const Offset(0, 4))]
                : [],
          );
        default:
          return BoxDecoration(
            color: enabled ? Colors.blueAccent : Colors.grey,
            shape: BoxShape.circle,
          );
      }
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: enabled ? () => _openLink(link) : null,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 56,
            height: 56,
            decoration: decoFor(brand),
            alignment: Alignment.center,
            child: FaIcon(icon, color: Colors.white, size: 26),
          ),
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.edit, size: 18),
              onPressed: () => _editLinkDialog(title, prefKey, link),
              tooltip: 'Editeaza linkul',
            ),
            IconButton(
              icon: const Icon(Icons.open_in_new, size: 18),
              onPressed: enabled ? () => _openLink(link) : null,
              tooltip: 'Deschide',
            ),
          ],
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final theme = Theme.of(context);
    final name = _nameCtrl.text.trim();

    final width = MediaQuery.of(context).size.width;
    final isSmall = width < 420;
    final avatarRadius = isSmall ? 48.0 : 60.0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveProfileToServer,
            tooltip: 'Salveaza',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(isSmall ? 12 : 16),
        child: Column(
          children: [
            GestureDetector(
              onTap: _showImageOptions,
              child: Stack(
                alignment: Alignment.bottomRight,
                children: [
                  Builder(builder: (_) {
                    ImageProvider? img;
                    // Prefer server avatar URL if present and no local override
                    if (_avatarUrl != null && _avatarUrl!.isNotEmpty && _avatarBytes == null && (_avatarPath == null || _avatarPath!.isEmpty)) {
                      img = NetworkImage(_avatarUrl!);
                    }
                    if (kIsWeb) {
                      if (_avatarBytes != null && _avatarBytes!.isNotEmpty) {
                        img = MemoryImage(_avatarBytes!);
                      }
                    } else {
                      if (_avatarPath != null &&
                          _avatarPath!.isNotEmpty &&
                          File(_avatarPath!).existsSync()) {
                        img = FileImage(File(_avatarPath!));
                      }
                    }
                    return CircleAvatar(
                      radius: avatarRadius,
                      backgroundColor: Colors.grey.shade200,
                      backgroundImage: img,
                      child: img == null
                          ? Text(
                              name.isNotEmpty
                                  ? name
                                      .split(' ')
                                      .map((e) => e.isNotEmpty ? e[0] : '')
                                      .take(2)
                                      .join()
                                  : '?',
                              style: const TextStyle(
                                  fontSize: 32, color: Colors.black54),
                            )
                          : null,
                    );
                  }),
                  Container(
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    padding: const EdgeInsets.all(6),
                    child: const Icon(Icons.camera_alt,
                        color: Colors.white, size: 18),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Nume',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _descCtrl,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Descriere',
                border: OutlineInputBorder(),
                alignLabelWithHint: true,
              ),
            ),
            SizedBox(height: isSmall ? 14 : 18),
            Align(
              alignment: Alignment.centerLeft,
              child: Text('Social media',
                  style: Theme.of(context).textTheme.titleMedium),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 18,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                _socialButton('facebook', FontAwesomeIcons.facebookF, _facebook, 'Facebook', 'profile_facebook'),
                _socialButton('instagram', FontAwesomeIcons.instagram, _instagram, 'Instagram', 'profile_instagram'),
                _socialButton('tiktok', FontAwesomeIcons.tiktok, _tiktok, 'TikTok', 'profile_tiktok'),
                _socialButton('youtube', FontAwesomeIcons.youtube, _youtube, 'YouTube', 'profile_youtube'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
